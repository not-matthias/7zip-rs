# 7zip-rs
Wrapper implementation for 7zip.
